import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd


# 定义绘制箱线图的函数
def plot_boxplot(data, title, x_labels, y_labels):
    # 创建箱体并设置样式
    fig, ax = plt.subplots()  # 创建一个图形及子图
    boxprops = dict(color="blue")  # 定义箱子的样式：边框颜色为蓝色，无填充
    medianprops = dict(
        color="red", linewidth=1
    )  # 定义中位数线的样式：颜色为红色，线宽为1
    whiskerprops = dict(
        color="black", linewidth=1.5, linestyle="--"
    )  # 定义须的样式：颜色为绿色，线宽为1.5，虚线
    flierprops = dict(
        marker="+", markerfacecolor="red", markeredgecolor="red", markersize=8
    )  # 定义异常值的样式

    # 绘制箱型图
    ax.boxplot(
        data,
        vert=True,
        patch_artist=False,  # 移除填充
        boxprops=boxprops,
        medianprops=medianprops,
        whiskerprops=whiskerprops,
        flierprops=flierprops,
    )

    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]  # 设置全局字体为微软雅黑

    # 添加标签
    ax.set_title(title, fontsize=16)  # 设置标题及字体大小
    ax.set_ylabel(y_labels, fontsize=12)  # 设置 Y 轴标签及字体大小
    ax.set_xticklabels(
        x_labels, rotation=45, fontsize=10
    )  # 更改 X 轴标签，并旋转 45 度
    ax.grid(
        True, linestyle="-", linewidth=0.5, alpha=0.5
    )  # 显示网格线，样式为实线，线宽为0.5，透明度为0.5

    # 保存图像
    # 将标题转换为文件名
    filename = title.replace(" ", "_") + ".png"
    plt.savefig(
        filename, dpi=600, bbox_inches="tight"
    )  # 保存图像为 PNG 格式，分辨率为 300 dpi

    # 显示图形并继续执行代码
    plt.show(block=False)

    # 设置计时器在5秒后关闭窗口
    plt.pause(5)
    plt.close()


def plot_comparison_boxplot(algorithm1_results, algorithm2_results, title, is_log):
    # 创建一个DataFrame来存储数据
    data = []
    for i in range(algorithm1_results.shape[1]):
        for j in range(algorithm1_results.shape[0]):
            data.append([i, algorithm1_results[j, i], "Original"])
            data.append([i, algorithm2_results[j, i], "Improved"])

    df = pd.DataFrame(data, columns=["Test Data", "Accuracy", "Algorithm"])

    # 创建箱体图
    plt.figure(figsize=(15, 8))

    sns.boxplot(
        x="Test Data",
        y="Accuracy",
        hue="Algorithm",
        data=df,
        palette={"Original": "lightblue", "Improved": "lightgreen"},
        medianprops=dict(color="red", linewidth=2),
        flierprops=dict(
            marker="+", markerfacecolor="red", markeredgecolor="red", markersize=8
        ),  # 定义异常值的样式
        whiskerprops=dict(color="black", linewidth=1.5, linestyle="--"),
    )

    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]
    plt.title(title, fontsize=16)
    plt.xlabel("Test Data", fontsize=12)
    if is_log:
        plt.ylabel("Accuracy(log)", fontsize=12)
    else:
        plt.ylabel("Accuracy", fontsize=12)
    plt.grid(True, linestyle="-", linewidth=0.5, alpha=0.5)

    # 保存并显示图像
    filename = title.replace(" ", "_") + ".png"
    plt.savefig(filename, dpi=300, bbox_inches="tight")

    # 显示图形并继续执行代码
    plt.show(block=False)

    # 设置计时器在5秒后关闭窗口
    plt.pause(5)
    plt.close()


def plot_multiple_lines(x, y_data, title, x_label, y_label, labels):
    """
    绘制多条折线图的函数

    参数:
    x (list): x轴数据
    y_data (list of lists): 多条折线的y轴数据
    title (str): 图表标题
    x_label (str): x轴标签
    y_label (str): y轴标签
    labels (list): 每条折线的标签
    """
    # Set font properties
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]

    # Create multiple line plots
    for y, label in zip(y_data, labels):
        plt.plot(x, y, linestyle="-", label=label)

    # Add title and labels with specified font sizes
    plt.title(title, fontsize=16)
    plt.xlabel(x_label, fontsize=12)
    plt.ylabel(y_label, fontsize=12)

    # Customize x-axis labels
    plt.xticks(rotation=45, fontsize=10)

    # Show legend
    plt.legend()

    # 保存并显示图像
    filename = title.replace(" ", "_") + ".png"
    plt.savefig(filename, dpi=300, bbox_inches="tight")

    # 显示图形并继续执行代码
    plt.show(block=False)

    # 设置计时器在5秒后关闭窗口
    plt.pause(5)
    plt.close()


# 定义绘制柱状图的函数
def plot_bar_chart(data, threshold, title, x_labels, y_label):
    count_above_threshold = [np.sum(np.array(group) < threshold) for group in data]
    # 设置全局字体为微软雅黑
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.figure(figsize=(12, 6))
    plt.bar(range(len(data)), count_above_threshold)
    plt.title(title, fontsize=16)
    # plt.xlabel(x_labels)
    plt.ylabel(y_label, fontsize=12)
    plt.xticks(ticks=np.arange(len(data)), labels=np.arange(len(data)), fontsize=10)
    filename = title.replace(" ", "_") + ".png"
    plt.savefig(
        filename, dpi=300, bbox_inches="tight"
    )  # 保存图像为 PNG 格式，分辨率为 300 dpi

    # 显示图形并继续执行代码
    plt.show(block=False)

    # 设置计时器在5秒后关闭窗口
    plt.pause(5)
    plt.close()
