import numpy as np
import scipy.stats as stats


def find_extrema(
    func, start, end, n, alpha, max_depth, current_depth=0, extrema_points=None
):
    # 定义标志常量
    INCREASING = 1
    DECREASING = 2
    UP_CONVEX = 3
    DOWN_CONVEX = 4

    # 初始化存储结果的列表
    if extrema_points is None:
        extrema_points = []

    # 生成区间内的等间距点
    x_values = np.linspace(start, end, n)
    y_values = np.array([func(x) for x in x_values])

    def classify_segment(y_start, y_middle, y_end):
        # 判断区间的增减性和凹凸性
        if y_start == np.min([y_start, y_middle, y_end]) and y_end == np.max(
            [y_start, y_middle, y_end]
        ):
            return INCREASING  # 递增
        elif y_end == np.min([y_start, y_middle, y_end]) and y_start == np.max(
            [y_start, y_middle, y_end]
        ):
            return DECREASING  # 递减
        elif y_middle == np.max([y_start, y_middle, y_end]):
            return UP_CONVEX  # 上凸
        elif y_middle == np.min([y_start, y_middle, y_end]):
            return DOWN_CONVEX  # 下凸

    def classify_all_segments(y_values):
        # 对所有相邻的三个点进行分类
        classifications = np.array(
            [
                classify_segment(y_values[i - 1], y_values[i], y_values[i + 1])
                for i in range(1, len(y_values) - 1)
            ]
        )
        return classifications

    # 获取所有区间的分类结果
    segment_classifications = classify_all_segments(y_values)

    for i in range(len(segment_classifications)):
        index = i + 1

        # 如果是下凸区间，递归查找子区间
        if segment_classifications[i] == DOWN_CONVEX:
            extrema_points.append(x_values[index])
            # 检查当前深度是否超过最大深度
            if current_depth < max_depth:
                # 每递归一次，n减少一点
                n = int(n * alpha)
                if n < 3:
                    n = 3
                find_extrema(
                    func,
                    x_values[index - 1],
                    x_values[index],
                    n,
                    alpha,
                    max_depth,
                    current_depth + 1,
                    extrema_points,
                )
                find_extrema(
                    func,
                    x_values[index],
                    x_values[index + 1],
                    n,
                    alpha,
                    max_depth,
                    current_depth + 1,
                    extrema_points,
                )
        # 如果是上凸区间
        elif segment_classifications[i] == UP_CONVEX:
            if i == len(segment_classifications) - 1:
                extrema_points.append(x_values[index + 1])
            continue
        # 如果是递减区间
        elif segment_classifications[i] == DECREASING:
            if i == len(segment_classifications) - 1:
                extrema_points.append(x_values[index + 1])
                continue
            if segment_classifications[i + 1] == DOWN_CONVEX:
                extrema_points.append(x_values[index + 1])
            continue

    return np.unique(extrema_points, axis=0)


def generate_Gaussian_Points(u, neigh_r, dim, size, pct_pts_neigh):
    sigma = np.abs(neigh_r) / stats.norm.ppf(0.5 + 0.5 * pct_pts_neigh ** (1 / dim))

    points = np.random.normal(loc=u, scale=sigma, size=(size, dim))

    return points


def diversity(Pop, lb, ub):
    return np.sum(np.sqrt(np.sum((Pop - np.mean(Pop, axis=0)) ** 2, axis=1))) / (
        Pop.shape[0] * np.sqrt(np.sum((ub - lb) ** 2))
    )


def split_into_chunks(total, chunk_size):
    chunks = [chunk_size for _ in range(total // chunk_size)]
    remainder = total % chunk_size
    if remainder:
        chunks.append(remainder)
    return chunks


def weight_lehmer_mean(num, weight, p):
    num = np.array(num)
    weight = np.array(weight)

    return np.sum(weight * num**p) / np.sum(weight * num ** (p - 1))


def softmax(num, b):
    exp_z = b**num
    return exp_z / np.sum(exp_z)
