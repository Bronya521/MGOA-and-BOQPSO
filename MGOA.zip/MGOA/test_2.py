import matplotlib.pyplot as plt
import numpy as np
from EA_toolbox import *



# 生成50组数据，每组100个数据
data = [np.random.randn(100) for _ in range(50)]
threshold = 0.5  # 给定数值

# 绘制柱状图
plot_bar_chart(data, threshold, "Bar Chart", "Group Number", "Count Above Threshold")
