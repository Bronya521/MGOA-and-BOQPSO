import numpy as np
from scipy.special import gamma


class Plant:
    def __init__(self, dim):
        self.Position = np.zeros((1, dim))
        self.Cost = np.inf
        self.GV = np.zeros((1, dim))


def random_sample(num_samples, dimensions, lower_limits, upper_limits):
    # 初始化样本矩阵
    samples = (
        np.random.rand(num_samples, dimensions) * (upper_limits - lower_limits)
        + lower_limits
    )
    return samples


def clip(individual_Position, lb, ub):
    individual_Position = np.maximum(individual_Position, lb)
    individual_Position = np.minimum(individual_Position, ub)

    return individual_Position


def growth_in_one_population(
    population,
    lb,
    ub,
    dim,
    fobj,
):
    """
    对单个种群进行操作
    """

    # 计算适应度的函数
    def CostFunction(x):
        return fobj(x)

    nPop = len(population)  # 种群大小
    VarSize = (1, dim)  # 决策变量矩阵大小
    pop = population

    # 对种群按适应度进行排序
    pop.sort(key=lambda x: x.Cost)

    # 初始化新种群
    newpop = []

    for i in range(len(pop)):
        # 获取最佳适应度值
        BestCost = pop[0].Cost

        # 选择邻居
        if i > 0:
            ii = i - 1
        else:
            ii = 0  # 最佳个体选择自己作为邻居

        newsol = Plant(dim)

        beta_parameter = 0.5
        beta = 1 + (np.random.rand() * beta_parameter)  # beta值

        # 全局
        if pop[i].Cost < beta * BestCost:
            # Eq.(5)-(6)
            newsol.Position = (
                pop[i].Position
                + np.abs(np.random.randn(*VarSize))
                * (pop[ii].Position - pop[i].Position)
                + np.random.randn(*VarSize) * pop[i].GV
            )

        # 局部
        else:
            # Eq.(7)
            newsol.Position = pop[0].Position * (
                np.random.rand(*VarSize) + np.random.randn(*VarSize) * pop[i].GV
            )

        pop[i].GV = pop[i].GV * (np.random.rand() ** 2) * np.random.randn(1, dim)
        # 边界检查
        newsol.Position = clip(newsol.Position, lb, ub)

        # Eq.(8)
        newsol.GV = (newsol.Position) / (ub - lb)

        # 评估新种群
        newsol.Cost = CostFunction(newsol.Position)
        newpop.append(newsol)

    # 合并种群
    pop.extend(newpop)

    # 排序种群
    pop.sort(key=lambda x: x.Cost)

    # 竞争性排除（删除多余成员）
    pop = pop[:nPop]

    return pop


def IVY(N, Max_iteration, lb, ub, dim, fobj):
    # 计算适应度的函数
    def CostFunction(x):
        return fobj(x)

    # IVYA参数
    MaxIt = Max_iteration  # 最大迭代次数
    nPop = N  # 种群大小

    # 初始化种群
    X = random_sample(
        num_samples=nPop, dimensions=dim, upper_limits=ub, lower_limits=lb
    )

    pop = [Plant(dim) for _ in range(nPop)]
    for i, plant in enumerate(pop):
        plant.Position = X[i].reshape(1, -1)
        plant.Cost = CostFunction(plant.Position)
    pop.sort(key=lambda x: x.Cost)
    for i, plant in enumerate(pop):
        plant.GV = plant.Position / (ub - lb)

    # 初始化收敛曲线
    Convergence_curve = np.zeros(MaxIt)

    # IVY主循环
    for it in range(MaxIt):
        pop = growth_in_one_population(
            population=pop,
            lb=lb,
            ub=ub,
            dim=dim,
            fobj=fobj,
        )

        # 存储迄今为止找到的最佳解决方案
        BestSol = pop[0]
        Convergence_curve[it] = BestSol.Cost
        # if it > 600 and BestSol.Cost > 1e-2:
        #     break
        # if it > 1200 and BestSol.Cost > 1e-4:
        #     break
        # if it > 2400 and BestSol.Cost > 1e-6:
        #     break
        # if it > 3600 and BestSol.Cost > 1e-8:
        #     break
        # if it > 4800 and BestSol.Cost > 1e-10:
        #     break

        # 显示迭代信息
        print(f"Iteration {it}: Best Cost = {BestSol.Cost}")

    # 结果
    Destination_fitness = BestSol.Cost
    Destination_position = BestSol.Position

    return (
        Destination_fitness,
        Destination_position,
        Convergence_curve,
    )
