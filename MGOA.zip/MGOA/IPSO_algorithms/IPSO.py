import numpy as np


# 子种群PSO类
class subpopPSO:
    def __init__(
        self, func, init_function, dim, size, iter_num, lb, ub, w_max, w_min, c1, c2
    ):
        self.func = func
        self.init_function = init_function
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.w_max = w_max
        self.w_min = w_min
        self.c1 = c1
        self.c2 = c2

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.P = self.X.copy()
        self.P_score = self.X_score.copy()
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)

        self.w = [0 for _ in range(self.size)]

    def calculate_w(self, t):
        d_matrix = np.zeros((self.size, self.size))
        for i in range(self.size):
            for j in range(self.size):
                d_matrix[i, j] = np.sum((self.X[i] - self.X[j]) ** 2)
        d_max = np.max(d_matrix)
        for i in range(self.size):
            d_i_gbest = np.sum((self.X[i] - self.gbest) ** 2)
            s = (d_i_gbest / d_max) ** 2
            self.w[i] = self.w_min + (self.w_max - self.w_min) * s * np.sqrt(
                (self.iter_num - t) / self.iter_num
            )

    def update_particles(self, i):
        r1, r2 = np.random.rand(), np.random.rand()
        velocities = (
            self.w[i] * self.X[i]
            + self.c1 * r1 * (self.P[i] - self.X[i])
            + self.c2 * r2 * (self.gbest - self.X[i])
        )
        self.X[i] = np.clip(self.X[i] + velocities, self.lb, self.ub)
        self.X_score[i] = self.func(self.X[i])

    def optimize(self, t):
        self.calculate_w(t)
        for i in range(self.size):
            self.update_particles(i)

        # 更新个体最优和全局最优
        for i in range(self.size):
            if self.X_score[i] < self.P_score[i]:
                self.P_score[i] = self.X_score[i]
                self.P[i] = self.X[i]
                if self.P_score[i] < self.gbest_score:
                    self.gbest_score = self.P_score[i]
                    self.gbest = self.P[i]

        best_index, worst_index = np.argsort(self.P_score)[[0, -1]]
        best_position, worst_position = self.P[[best_index, worst_index]]

        return (
            [best_index, worst_index],
            [best_position, worst_position],
            self.gbest_score,
        )


# 改进PSO类
class IPSO:
    def __init__(
        self,
        func,
        init_function,
        dim,
        size,
        iter_num,
        lb,
        ub,
        is_find_PS,
        is_print,
        w_max,
        w_min,
        c1,
        c2,
        subpop_count,
    ):
        self.func = func
        self.init_function = init_function
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_find_PS = is_find_PS
        self.is_print = is_print
        self.w_max = w_max
        self.w_min = w_min
        self.c1 = c1
        self.c2 = c2
        self.subpop_count = subpop_count

        self.gbest_scores = []
        self.subPops = []

    def init_subPops(self):
        # 计算每个子种群有多少个个体
        a = self.size // self.subpop_count
        remainder = self.size % self.subpop_count
        subPop_size = [a + 1 if i < remainder else a for i in range(self.subpop_count)]

        for i in range(self.subpop_count):
            self.subPops.append(
                subpopPSO(
                    self.func,
                    self.init_function,
                    self.dim,
                    subPop_size[i],
                    self.iter_num,
                    self.lb,
                    self.ub,
                    self.w_max,
                    self.w_min,
                    self.c1,
                    self.c2,
                )
            )

    def immigration(self, subpop_best_worst_index, subpop_best_worst_position):
        subpop_best_worst_index = np.array(subpop_best_worst_index)
        subpop_best_worst_position = np.array(subpop_best_worst_position)
        for k in range(self.subpop_count):
            if k < self.subpop_count - 1:
                self.subPops[k + 1].X[subpop_best_worst_index[k + 1, 1]] = (
                    subpop_best_worst_position[k, 0]
                )
            else:
                self.subPops[0].X[subpop_best_worst_index[0, 1]] = (
                    subpop_best_worst_position[-1, 0]
                )

    def optimize(self):
        self.init_subPops()

        for t in range(self.iter_num):
            subpop_best_worst_index = []
            subpop_best_worst_position = []
            subpop_best_scores = []
            for i in range(self.subpop_count):
                index, position, best_score = self.subPops[i].optimize(t)
                subpop_best_worst_index.append(index)
                subpop_best_worst_position.append(position)
                subpop_best_scores.append(best_score)

            self.immigration(subpop_best_worst_index, subpop_best_worst_position)

            self.gbest_scores.append(np.min(subpop_best_scores))
            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return None, self.gbest_scores[-1], None, None, None
