import numpy as np


# EO算法类
class EOSMA:
    def __init__(
        self,
        func,
        init_function,
        dim,
        size,
        iter_num,
        lb,
        ub,
        is_find_PS,
        is_print,
        a_1,
        a_2,
        V,
        q,
    ):
        self.func = func
        self.init_function = init_function
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_find_PS = is_find_PS
        self.is_print = is_print
        self.a_1 = a_1
        self.a_2 = a_2
        self.V = V
        self.q = q

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.P = self.X.copy()
        self.P_score = self.X_score.copy()
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = []

        self.pool = np.zeros((5, self.dim))
        self.F = np.zeros((self.size, self.dim))
        self.W = [0 for _ in range(self.size)]
        self.a = 0

    def updata_pool_g_p_best(self):
        # 更新个体历史最优
        for i in range(self.size):
            if self.X_score[i] < self.P_score[i]:
                self.P[i] = self.X[i].copy()
                self.P_score[i] = self.X_score[i]

        # 更新全局历史最优和池
        best_4_index = np.argsort(self.P_score)[:4]
        self.pool[:4] = self.P[best_4_index].copy()
        self.pool[4] = np.mean(self.pool[:4], axis=0)

        self.gbest = self.P[best_4_index[0]].copy()
        self.gbest_score = self.P_score[best_4_index[0]]
        self.gbest_scores.append(self.gbest_score)

    def calculate_F_a(self, t):
        t = t + 1
        t_1 = (1 - t / self.iter_num) ** (self.a_2 * t / self.iter_num)
        for i in range(self.size):
            self.F[i] = (
                self.a_1
                * np.sign(np.random.rand(self.dim) - 0.5)
                * (np.exp(-np.random.rand(self.dim) * t_1) - 1)
            )

        b = 1 - (t + 1) / self.iter_num
        self.a = np.arctanh(b)

    def calculate_W(self):
        random_factor = np.random.rand(self.size)
        argsort_index = np.argsort(self.X_score)
        best_fitness = self.X_score[argsort_index[0]]
        worst_fitness = self.X_score[argsort_index[-1]]
        for i in range(self.size):
            a = (
                np.log(
                    (best_fitness - self.X_score[i]) / (best_fitness - worst_fitness)
                    + 1
                )
                * random_factor[i]
            )
            if i < self.size // 2:
                self.W[i] = 1 + a
            else:
                self.W[i] = 1 - a

    def EO_calculate(self, i):
        C_eq = self.pool[np.random.choice(5)]
        G_CP = 0.5 * np.random.rand(self.dim) if np.random.rand() < 0.5 else 0
        G = G_CP * (C_eq - np.random.rand(self.dim) * self.X[i])
        self.X[i] = (
            C_eq
            + (self.P[i] - C_eq) * self.F[i]
            + G * (1 - self.F[i]) / (np.random.rand(self.dim) * self.V)
        )
        # 边界检查
        self.X[i] = np.clip(self.X[i], self.lb, self.ub)
        self.X_score[i] = self.func(self.X[i])

    def SMA_calculate(self, i):
        chosen_index = np.random.choice(np.arange(self.size), 2, replace=False)
        self.X[i] = self.gbest + np.random.uniform(-self.a, self.a) * (
            self.W[i] * self.P[chosen_index[0]] - self.P[chosen_index[1]]
        )

    def mutation(self, i):
        SF = np.random.rand(self.dim) * 0.3 + 0.3
        chosen_index = np.random.choice(np.arange(self.size), 3, replace=False)
        self.X[i] = self.P[chosen_index[0]] + SF * (
            self.P[chosen_index[1]] - self.P[chosen_index[2]]
        )

    def individual_range(self, i):
        out_ub_index = np.where(self.X[i] > self.ub)[0]
        out_lb_index = np.where(self.X[i] < self.lb)[0]
        if len(out_lb_index) != 0:
            self.X[i][out_lb_index] = (
                self.X[i][out_lb_index] + self.lb[out_lb_index]
            ) / 2
        if len(out_ub_index) != 0:
            self.X[i][out_ub_index] = (
                self.X[i][out_ub_index] + self.ub[out_ub_index]
            ) / 2

    def optimize(self):
        for t in range(self.iter_num):
            # 计算
            self.updata_pool_g_p_best()
            self.calculate_F_a(t)
            self.calculate_W()

            for i in range(self.size):
                if np.random.rand() >= self.q:
                    if np.random.rand() < 0.5:
                        self.EO_calculate(i)
                    else:
                        self.SMA_calculate(i)
                else:
                    self.mutation(i)

                self.individual_range(i)

            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return None, self.gbest_score, None, None, None
