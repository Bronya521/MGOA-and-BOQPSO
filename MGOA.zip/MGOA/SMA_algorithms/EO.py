import numpy as np


# 定义Rosenbrock函数作为目标函数
def rosenbrock(x):
    return sum(100.0 * (x[1:] - x[:-1] ** 2.0) ** 2.0 + (1 - x[:-1]) ** 2.0)


# 初始化函数
def init_function(lb, ub, dim, size):
    return np.random.uniform(lb, ub, (size, dim))


# EO算法类
class EO_original:
    def __init__(
        self,
        func,
        init_function,
        dim,
        size,
        iter_num,
        lb,
        ub,
        is_find_PS,
        is_print,
        a_1,
        a_2,
        V,
    ):
        self.func = func
        self.init_function = init_function
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_find_PS = is_find_PS
        self.is_print = is_print
        self.a_1 = a_1
        self.a_2 = a_2
        self.V = V

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]

        self.pool = np.zeros((5, self.dim))
        self.F = np.zeros((self.size, self.dim))

    def updata_pool_gbest(self):
        best_4_index = np.argsort(self.X_score)[:4]
        self.pool[:4] = self.X[best_4_index].copy()
        self.pool[4] = np.mean(self.pool[:4], axis=0)

        self.gbest = self.X[best_4_index[0]].copy()
        self.gbest_score = self.X_score[best_4_index[0]]
        self.gbest_scores.append(self.gbest_score)

    def calculate_F(self, t):
        t = t + 1
        t_1 = (1 - t / self.iter_num) ** (self.a_2 * t / self.iter_num)
        for i in range(self.size):
            self.F[i] = (
                self.a_1
                * np.sign(np.random.rand(self.dim) - 0.5)
                * (np.exp(-np.random.rand(self.dim) * t_1) - 1)
            )

    def optimize(self):
        for t in range(self.iter_num):
            # 计算
            self.updata_pool_gbest()
            self.calculate_F(t)

            for i in range(self.size):
                C_eq = self.pool[np.random.choice(5)]
                G_CP = 0.5 * np.random.rand(self.dim) if np.random.rand() < 0.5 else 0
                G = G_CP * (C_eq - np.random.rand(self.dim) * self.X[i])
                self.X[i] = (
                    C_eq
                    + (self.X[i] - C_eq) * self.F[i]
                    + G * (1 - self.F[i]) / (np.random.rand(self.dim) * self.V)
                )
                # 边界检查
                self.X[i] = np.clip(self.X[i], self.lb, self.ub)
                self.X_score[i] = self.func(self.X[i])

            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return self.gbest_score, self.gbest_scores


# # 测试EO算法
# if __name__ == "__main__":
#     dim = 10
#     size = 100
#     iter_num = 1000
#     lb = -5.0
#     ub = 5.0
#     a_1 = 2.0
#     a_2 = 1.5
#     V = 10
#     is_find_PS = False
#     is_print = True

#     eo = EO_original(
#         rosenbrock,
#         init_function,
#         dim,
#         size,
#         iter_num,
#         lb,
#         ub,
#         is_find_PS,
#         is_print,
#         a_1,
#         a_2,
#         V,
#     )
#     best_score, score_history = eo.optimize()

#     print(f"Best Score: {best_score}")
