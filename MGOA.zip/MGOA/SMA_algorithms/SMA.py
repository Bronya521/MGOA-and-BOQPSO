import numpy as np

# SMA算法类
class SMA_original:
    def __init__(
        self, func, init_function, dim, size, iter_num, lb, ub, is_find_PS, is_print, z
    ):
        self.func = func
        self.init_function = init_function
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_find_PS = is_find_PS
        self.is_print = is_print
        self.z = z

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]
        self.history_gbest = self.gbest.copy()
        self.history_gbest_score = self.gbest_score

        self.W = [0 for _ in range(self.size)]
        self.a = 0
        self.b = 0
        self.p = [0 for _ in range(self.size)]

    def calculate_W(self):
        random_factor = np.random.rand(self.size)
        best_fitness = self.X_score[0]
        worst_fitness = self.X_score[-1]
        for i in range(self.size):
            a = (
                np.log(
                    (best_fitness - self.X_score[i]) / (best_fitness - worst_fitness)
                    + 1
                )
                * random_factor[i]
            )
            if i < self.size // 2:
                self.W[i] = 1 + a
            else:
                self.W[i] = 1 - a

        self.gbest = self.X[0]
        self.gbest_score = self.X_score[0]
        if self.gbest_score < self.history_gbest_score:
            self.history_gbest_score = self.gbest_score
            self.history_gbest = self.gbest.copy()
        self.gbest_scores.append(self.history_gbest_score)

    def calculate_a_b_p(self, t):
        self.b = 1 - (t + 1) / self.iter_num
        self.a = np.arctanh(self.b)
        for i in range(self.size):
            self.p[i] = np.tanh(np.abs(self.X_score[i] - self.history_gbest_score))

    def optimize(self):
        for t in range(self.iter_num):
            # 排序
            sort_index = np.argsort(self.X_score)
            self.X = self.X[sort_index]
            self.X_score = self.X_score[sort_index]
            # 计算
            self.calculate_W()
            self.calculate_a_b_p(t)

            for i in range(self.size):
                random_num = np.random.rand()
                if random_num < self.z:
                    self.X[i] = np.random.uniform(self.lb, self.ub, self.dim)
                elif random_num < self.p[i]:
                    index_list = [index for index in range(self.size) if index != i]
                    chosen_index = np.random.choice(index_list, 2, replace=False)
                    self.X[i] = self.gbest + np.random.uniform(-self.a, self.a) * (
                        self.W[i] * self.X[chosen_index[0]] - self.X[chosen_index[1]]
                    )
                else:
                    self.X[i] = np.random.uniform(-self.b, self.b) * self.X[i]
                self.X[i] = np.clip(self.X[i], self.lb, self.ub)
                self.X_score[i] = self.func(self.X[i])

            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return self.history_gbest_score, self.gbest_scores
