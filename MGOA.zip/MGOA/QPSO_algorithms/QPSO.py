import array
import numpy as np
import matplotlib.pyplot as plt
from EA_toolbox import *
import time


class QPSO_global_original:
    def __init__(
        self, func, init_function, dim, size, iter_num, lb, ub, is_find_PS, is_print, a
    ):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_find_PS = is_find_PS
        self.is_print = is_print
        self.a = a

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.P = self.X.copy()
        self.P_score = self.X_score.copy()
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]

        self.potential_solutions = []

    def initPopReplace(self, good_individuals):
        count = good_individuals.shape[0]
        all_index = np.arange(self.size)
        selected_index = np.random.choice(all_index, size=count, replace=False)
        self.X[selected_index] = good_individuals.copy()

    def optimize(self):
        for t in range(self.iter_num):
            # 个体历史最优均值
            average_p = np.sum(self.P, axis=0) / self.size
            # 粒子进行运动
            for i in range(self.size):
                # 计算吸引子位置
                random_factor = np.random.rand(self.dim)
                p = random_factor * self.P[i] + (1 - random_factor) * self.gbest
                # 向吸引子运动
                random_factor_log = np.random.rand(self.dim)
                random_factor_sign = np.random.uniform(low=-1, high=1, size=self.dim)
                new_X = p + np.sign(random_factor_sign) * self.a * np.abs(
                    average_p - self.X[i]
                ) * np.log(1 / random_factor_log)
                # 将新解限制在范围内
                new_X = np.clip(new_X, self.lb, self.ub)
                new_score = self.func(new_X)
                # 寻找潜力解
                if self.is_find_PS and t < self.iter_num // 2:
                    potential_solutions = find_extrema(
                        self.func,
                        start=self.X[i],
                        end=new_X,
                        n=11,
                        alpha=0.7,
                        max_depth=3,
                    )
                    self.potential_solutions.extend(potential_solutions)
                # 更新当前种群
                self.X[i] = new_X.copy()
                self.X_score[i] = new_score.copy()
                # 更新个体最优
                if self.X_score[i] < self.P_score[i]:
                    self.P[i] = self.X[i].copy()
                    self.P_score[i] = self.X_score[i].copy()
                    # 更新全局最优
                    if self.P_score[i] < self.gbest_score:
                        self.gbest = self.P[i].copy()
                        self.gbest_score = self.P_score[i].copy()

            self.gbest_scores.append(self.gbest_score)
            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return (
            self.gbest,
            self.gbest_score,
            np.array(self.potential_solutions),
            None,
            self.gbest_scores,
        )

    def plot_optimization(self):
        plt.semilogy(self.gbest_scores, "r-", linewidth=2)
        plt.xlabel("Iteration")
        plt.ylabel("Best Score")
        plt.title("PSO Optimization Process")
        plt.show()


class QPSO_global_improved:
    def __init__(
        self,
        func,
        init_function,
        dim,
        size,
        iter_num,
        lb,
        ub,
        is_find_PS,
        is_print,
        H,
        subPop_count,
        is_subpopulation=None,
    ):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_find_PS = is_find_PS
        self.is_print = is_print
        self.H = H
        self.subPop_count = subPop_count
        self.is_subpopulation = is_subpopulation

        if not self.is_subpopulation:
            self.X = init_function(self.lb, self.ub, self.dim, self.size)
            self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
            self.P = self.X.copy()
            self.P_score = self.X_score.copy()
            self.gbest = self.X[np.argmin(self.X_score)].copy()
            self.gbest_score = np.min(self.X_score)
            self.gbest_scores = [self.gbest_score]
        else:
            self.X = np.zeros((self.size, self.dim))
            self.X_score = np.zeros(self.size)
            self.P = np.zeros((self.size, self.dim))
            self.P_score = np.zeros(self.size)
            self.gbest = None
            self.gbest_score = None
            self.gbest_scores = None

        self.a = None
        self.M_a = np.array([0.5 for _ in range(self.H)])
        self.k = np.random.choice(self.H)
        self.Set_success_a = []
        self.weight = []

        self.potential_solutions = []
        self.potential_solutions_fitness = []

    def initPopReplace(self, good_individuals):
        count = good_individuals.shape[0]
        all_index = np.arange(self.size)
        selected_index = np.random.choice(all_index, size=count, replace=False)

        self.X[selected_index] = good_individuals.copy()
        self.X_score[selected_index] = np.array(
            [self.func(self.X[i]) for i in selected_index]
        )
        self.P[selected_index] = self.X[selected_index].copy()
        self.P_score[selected_index] = self.X_score[selected_index].copy()
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]

    def subPop_optimize(self):
        # 计算每个子种群有多少个个体
        def calculate_subPop_size():
            a = self.size // self.subPop_count
            remainder = self.size % self.subPop_count
            subPop_size = [
                a + 1 if i < remainder else a for i in range(self.subPop_count)
            ]
            return subPop_size

        # 为子种群分配索引
        def assign_subPop_indices():
            subPop_size = calculate_subPop_size()
            shuffled_index = np.random.choice(self.size, self.size, replace=False)
            subPop_index = []
            start = 0
            for size in subPop_size:
                subPop_index.append(shuffled_index[start : start + size])
                start += size
            return subPop_index

        # 如果该种群不是子种群，那么生成子种群并开始优化
        if not self.is_subpopulation:
            subPop_index = assign_subPop_indices()
            # 创建子种群
            subPop_list = [
                QPSO_global_improved(
                    func=self.func,
                    init_function=None,
                    dim=self.dim,
                    size=len(subPop_index[i]),
                    iter_num=self.iter_num,
                    lb=self.lb,
                    ub=self.ub,
                    is_find_PS=self.is_find_PS,
                    is_print=self.is_print,
                    H=self.H,
                    subPop_count=0,
                    is_subpopulation=True,
                )
                for i in range(self.subPop_count)
            ]
            # 临时存储子种群的最优解、潜在解、优化过程曲线和末代种群
            # 所有子种群的潜在解和末代种群都存储，最优解和优化过程只存储最优的子种群的
            subPop_best_position = None
            subPop_best_fitness = np.inf
            subPop_PS = None
            subPop_PS_fitness = None
            subPop_curve = None
            subPop_endPop = None
            subPop_endPop_score = None
            subPop_endPop_p = None
            subPop_endPop_p_score = None
            # 为子种群分配个体，并开始优化
            for i in range(self.subPop_count):
                if self.is_print:
                    print(f"第{i+1}个子种群正在优化")
                subPop_list[i].initPopReplace(self.X[subPop_index[i]])
                subPop_list[i].optimize()
                # 存储潜在解和末代种群
                if subPop_PS is None:
                    subPop_PS = subPop_list[i].potential_solutions.copy()
                    subPop_PS_fitness = subPop_list[
                        i
                    ].potential_solutions_fitness.copy()
                    subPop_endPop = subPop_list[i].X.copy()
                    subPop_endPop_score = subPop_list[i].X_score.copy()
                    subPop_endPop_p = subPop_list[i].P.copy()
                    subPop_endPop_p_score = subPop_list[i].P_score.copy()
                else:
                    subPop_PS = np.concatenate(
                        (subPop_PS, subPop_list[i].potential_solutions.copy()), axis=0
                    )
                    subPop_PS_fitness = np.concatenate(
                        (
                            subPop_PS_fitness,
                            subPop_list[i].potential_solutions_fitness.copy(),
                        ),
                        axis=0,
                    )
                    subPop_endPop = np.concatenate(
                        (subPop_endPop, subPop_list[i].X.copy()), axis=0
                    )
                    subPop_endPop_score = np.concatenate(
                        (subPop_endPop_score, subPop_list[i].X_score.copy())
                    )
                    subPop_endPop_p = np.concatenate(
                        (subPop_endPop_p, subPop_list[i].P.copy()), axis=0
                    )
                    subPop_endPop_p_score = np.concatenate(
                        (subPop_endPop_p_score, subPop_list[i].P_score.copy())
                    )
                # 存储最优解和优化过程
                if subPop_list[i].gbest_score < subPop_best_fitness:
                    subPop_best_position = subPop_list[i].gbest
                    subPop_best_fitness = subPop_list[i].gbest_score
                    subPop_curve = subPop_list[i].gbest_scores
            # 将最优解、潜在解、优化过程曲线和所有的末代种群都替换掉父代种群相应变量
            self.X = subPop_endPop
            self.X_score = subPop_endPop_score
            self.P = subPop_endPop_p
            self.P_score = subPop_endPop_p_score
            self.gbest = subPop_best_position
            self.gbest_score = subPop_best_fitness
            self.gbest_scores = subPop_curve

            # 以历史最优为指标，先将父代种群中最差的一半个体删除
            # 然后在剩下的种群中，将最差的一半个体初始化在另一半的当前位置和全局最优中间
            self.size = self.size // 2
            sorted_indices = np.argsort(self.P_score)[: self.size]
            self.X = self.X[sorted_indices]
            self.X_score = self.X_score[sorted_indices]
            self.P = self.P[sorted_indices]
            self.P_score = self.P_score[sorted_indices]

            sorted_indices = np.argsort(self.P_score)
            half_size = self.size // 2
            if self.size % 2 == 0:
                best_index = sorted_indices[:half_size]
                worst_index = sorted_indices[half_size:]
            else:
                best_index = sorted_indices[: half_size + 1]
                worst_index = sorted_indices[half_size + 1 :]
            random_factor = np.random.rand(len(worst_index), self.dim)
            np.random.shuffle(best_index)
            for i in range(len(worst_index)):
                self.X[worst_index[i]] = (
                    random_factor[i] * self.gbest
                    + (1 - random_factor[i]) * best_index[i]
                )
                self.X_score[worst_index[i]] = self.func(self.X[worst_index[i]])
                self.P[worst_index[i]] = self.X[worst_index[i]].copy()
                self.P_score[worst_index[i]] = self.X_score[worst_index[i]].copy()
                # 更新全局最优
                if self.P_score[worst_index[i]] < self.gbest_score:
                    self.gbest = self.P[worst_index[i]].copy()
                    self.gbest_score = self.P_score[worst_index[i]].copy()

    def find_PS(self, new_X, new_score, t):
        if self.is_find_PS and t < self.iter_num // 2:
            self.potential_solutions.append(new_X.copy())
            self.potential_solutions_fitness.append(new_score.copy())

    def updata_pop_restore_a(self, i, new_X, new_score):
        self.X[i] = new_X.copy()
        self.X_score[i] = new_score.copy()
        # 更新个体最优
        if self.X_score[i] < self.P_score[i]:
            # 存储成功的a及其权重
            self.Set_success_a.append(self.a[i])
            self.weight.append(np.abs(self.X_score[i] - self.P_score[i]))
            # 更新个体最优
            self.P[i] = self.X[i].copy()
            self.P_score[i] = self.X_score[i].copy()
            # 更新全局最优
            if self.P_score[i] < self.gbest_score:
                self.gbest = self.P[i].copy()
                self.gbest_score = self.P_score[i].copy()

    def updata_Ma_list(self):
        if len(self.weight) != 0:
            self.M_a[self.k] = np.clip(
                weight_lehmer_mean(self.Set_success_a, self.weight, 2), 0.4, 1.782
            )

            self.k += 1
            if self.k >= self.H:
                self.k = 0

        self.Set_success_a = []
        self.weight = []

    def calculate_a(self):
        # 随机选取一个Ma作为期望
        index_random = np.random.choice(self.H)
        selected_M_a = self.M_a[index_random]
        # 正态分布
        self.a = np.random.normal(loc=selected_M_a, scale=0.1, size=self.size)
        self.a = np.clip(self.a, 0.2, 1.782)

    def get_p(self, i):
        loc = self.a[i] ** 0.5
        scale = 0.1

        random_factor = np.random.normal(loc=loc, scale=scale, size=self.dim)
        p = (1 - random_factor) * self.P[i] + random_factor * self.gbest
        p = np.clip(p, self.lb, self.ub)

        return p

    def optimize(self):
        self.subPop_optimize()
        for t in range(self.iter_num):
            # 个体历史最优均值
            average_p = np.sum(self.P, axis=0) / self.size
            # 计算收缩膨胀因子a
            self.calculate_a()
            # 粒子进行运动
            for i in range(self.size):
                # 计算吸引子位置
                p = self.get_p(i)
                # 向吸引子运动
                random_factor_log = np.random.rand(self.dim)
                random_factor_sign = np.random.uniform(low=-1, high=1, size=self.dim)
                new_X = p + np.sign(random_factor_sign) * self.a[i] * np.abs(
                    average_p - self.X[i]
                ) * np.log(1 / random_factor_log)
                # 将新解限制在范围内
                new_X = np.clip(new_X, self.lb, self.ub)
                new_score = self.func(new_X)
                # 寻找潜力解
                self.find_PS(new_X, new_score, t)
                # 更新当前种群和存储成功的a
                self.updata_pop_restore_a(i, new_X, new_score)
            # 调整Ma列表
            self.updata_Ma_list()

            self.gbest_scores.append(self.gbest_score)
            if self.is_print:
                print(
                    f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}, a:{np.mean(self.a)}"
                )

        return (
            self.gbest,
            self.gbest_score,
            np.array(self.potential_solutions),
            np.array(self.potential_solutions_fitness),
            self.gbest_scores,
        )
