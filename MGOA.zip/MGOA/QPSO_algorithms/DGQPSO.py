import numpy as np
import matplotlib.pyplot as plt
from EA_toolbox import *


class DGQPSO_global_original:
    def __init__(
        self,
        func,
        init_function,
        dim,
        size,
        iter_num,
        lb,
        ub,
        is_find_PS,
        is_print,
        a_max,
        a_min,
        d_low,
        r,
        type,
    ):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_find_PS = is_find_PS
        self.is_print = is_print
        self.a_max = a_max
        self.a_min = a_min
        self.d_low = d_low
        self.r = r
        self.type = type

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.P = self.X.copy()
        self.P_score = self.X_score.copy()
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]

        self.a = 0
        self.average_p = np.sum(self.P, axis=0) / self.size

        self.potential_solutions = []

    def initPopReplace(self, good_individuals):
        count = good_individuals.shape[0]
        all_index = np.arange(self.size)
        selected_index = np.random.choice(all_index, size=count, replace=False)
        self.X[selected_index] = good_individuals.copy()

    def optimize(self):
        for t in range(self.iter_num):
            # 根据迭代次数和多样性来决定参数
            self.adjust_para(t)
            # 个体历史最优均值
            self.average_p = np.sum(self.P, axis=0) / self.size
            # 粒子进行运动
            for i in range(self.size):
                # 计算吸引子位置
                random_factor = np.random.rand(self.dim)
                p = random_factor * self.P[i] + (1 - random_factor) * self.gbest
                # 向吸引子运动
                random_factor_log = np.random.rand(self.dim)
                random_factor_sign = np.random.uniform(low=-1, high=1, size=self.dim)
                new_X = p + np.sign(random_factor_sign) * self.a * np.abs(
                    self.average_p - self.X[i]
                ) * np.log(1 / random_factor_log)
                # 将新解限制在范围内
                new_X = np.clip(new_X, self.lb, self.ub)
                new_score = self.func(new_X)

                # 更新当前种群
                self.X[i] = new_X.copy()
                self.X_score[i] = new_score.copy()
                # 更新个体最优
                if self.X_score[i] < self.P_score[i]:
                    self.P[i] = self.X[i].copy()
                    self.P_score[i] = self.X_score[i].copy()
                    # 更新全局最优
                    if self.P_score[i] < self.gbest_score:
                        self.gbest = self.P[i].copy()
                        self.gbest_score = self.P_score[i].copy()

            self.gbest_scores.append(self.gbest_score)
            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return (
            self.gbest,
            self.gbest_score,
            np.array(self.potential_solutions),
            None,
            self.gbest_scores,
        )

    def adjust_para(self, t):
        self.a = (self.a_max - self.a_min) * (
            self.iter_num - t
        ) / self.iter_num + self.a_min

        if self.type == "x":
            Pop = self.X.copy()
        else:
            Pop = self.P.copy()
        if diversity(Pop, self.lb, self.ub) < self.d_low:
            gbest_index = np.argmin(self.P_score)
            self.P[gbest_index] = self.P[gbest_index] + self.r * np.sqrt(
                np.sum((self.ub - self.lb) ** 2)
            ) * np.random.standard_normal(self.dim)
            self.X[gbest_index] = self.P[gbest_index].copy()
            self.X_score[gbest_index] = self.func(self.X[gbest_index])
            self.P_score[gbest_index] = self.X_score[gbest_index].copy()

    def plot_optimization(self):
        plt.semilogy(self.gbest_scores, "r-", linewidth=2)
        plt.xlabel("Iteration")
        plt.ylabel("Best Score")
        plt.title("PSO Optimization Process")
        plt.show()
