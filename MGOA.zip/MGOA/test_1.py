import matplotlib.pyplot as plt
import numpy as np

# 生成圆周上的点
theta = np.linspace(0, 2 * np.pi, 100)
radius = np.ones_like(theta) * (1 + np.random.randn(100)/100)
x = radius * np.cos(theta)
y = radius * np.sin(theta)

# 绘制不相交的闭合曲线
plt.figure(figsize=(8, 6))
plt.plot(x, y, marker="o")
plt.fill(x, y, alpha=0.3)
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.title("Non-intersecting Irregular Closed Curve")
plt.grid(True)
plt.show()
