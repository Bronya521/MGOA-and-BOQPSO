import numpy as np
import matplotlib.pyplot as plt
from EA_toolbox import *


class DE_global_original:
    def __init__(
        self,
        func,
        init_function,
        dim,
        size,
        iter_num,
        lb,
        ub,
        is_find_PS,
        is_print,
        mut,
        crossp,
    ):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = np.array(lb)
        self.ub = np.array(ub)
        self.is_find_PS = is_find_PS
        self.is_print = is_print
        self.mut = mut
        self.crossp = crossp

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]

        self.potential_solutions = []

    def optimize(self):
        for t in range(self.iter_num):

            for j in range(self.size):
                idxs = [idx for idx in range(self.size) if idx != j]
                a, b, c = self.X[np.random.choice(idxs, 3, replace=False)]
                mutant = np.clip(a + self.mut * (b - c), self.lb, self.ub)
                cross_points = np.random.rand(self.dim) < self.crossp
                if not np.any(cross_points):
                    cross_points[np.random.randint(0, self.dim)] = True
                trial = np.where(cross_points, mutant, self.X[j])
                score_trial = self.func(trial)
                if score_trial < self.X_score[j]:
                    self.X_score[j] = score_trial
                    self.X[j] = trial
                    if score_trial < self.gbest_score:
                        self.gbest_score = score_trial
            self.gbest_scores.append(self.gbest_score)

            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return (
            self.gbest,
            self.gbest_score,
            np.array(self.potential_solutions),
            None,
            self.gbest_scores,
        )

    def plot_optimization(self):
        plt.semilogy(self.gbest_scores, "r-", linewidth=2)
        plt.xlabel("Iteration")
        plt.ylabel("Best Score")
        plt.title("DE Optimization Process")
        plt.show()
