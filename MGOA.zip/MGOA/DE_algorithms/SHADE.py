import numpy as np
import matplotlib.pyplot as plt
from EA_toolbox import *


class SHADE_global_original:
    def __init__(
        self, func, init_function, dim, size, iter_num, lb, ub, is_find_PS, is_print, H
    ):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = np.array(lb)
        self.ub = np.array(ub)
        self.is_find_PS = is_find_PS
        self.is_print = is_print
        self.H = H

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]

        # ?????????????
        self.mut = None
        self.crossp = None
        self.A = None
        self.M_CR = np.array([0.5 for _ in range(self.H)])
        self.M_F = np.array([0.5 for _ in range(self.H)])
        self.k = 0

        self.potential_solutions = []

    def adapt_parameters(self, weight, Set_crossp, Set_F):
        def weight_lehmer_mean(num, weight):
            num = np.array(num)
            weight = np.array(weight)
            return np.sum(weight * num**2) / np.sum(weight * num)

        def weight_mean(num, weight):
            num = np.array(num)
            weight = np.array(weight)
            weight = weight / np.sum(weight)
            return np.sum(weight * num)

        if len(weight) != 0:
            self.M_CR[self.k] = np.clip(weight_mean(Set_crossp, weight), 0, 1)
            self.M_F[self.k] = np.clip(weight_lehmer_mean(Set_F, weight), 0, 1)

        self.k += 1
        if self.k >= self.H:
            self.k = 0

    def initPopReplace(self, good_individuals):
        count = good_individuals.shape[0]
        all_index = np.arange(self.size)
        selected_index = np.random.choice(all_index, size=count, replace=False)
        self.X[selected_index] = good_individuals.copy()

    def optimize(self):
        for t in range(self.iter_num):
            # ??????????????????????
            Set_crossp = []
            Set_F = []
            weight = []
            # ?????????????????????????
            mergeSet_A_P = self.merge_A_P()
            # ???????????????????????
            A_list = []
            # ??????????????????
            self.calculate_F_CR()

            for individual_index in range(self.size):
                # ??????????1?7
                mutant = self.generate_mutant(mergeSet_A_P, individual_index)

                # ?????????????????????????????????????
                cross_points = np.random.rand(self.dim) < self.crossp[individual_index]
                # ???????????????????????????????
                if not np.any(cross_points):
                    cross_points[np.random.randint(0, self.dim)] = True
                # ??????????????????????1?7
                trial = np.where(cross_points, mutant, self.X[individual_index])
                score_trial = self.func(trial)
                # ??????????????????????????
                if score_trial < self.X_score[individual_index]:
                    Set_crossp.append(self.crossp[individual_index])
                    Set_F.append(self.mut[individual_index])
                    A_list.append(self.X[individual_index].copy())
                    weight.append(np.abs(score_trial - self.X_score[individual_index]))
                    self.X_score[individual_index] = score_trial
                    self.X[individual_index] = trial
                    if score_trial < self.gbest_score:
                        self.gbest_score = score_trial

            self.operate_A(A_list)

            # ???????????
            self.gbest_scores.append(self.gbest_score)
            self.adapt_parameters(weight, Set_crossp, Set_F)
            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return (
            self.gbest,
            self.gbest_score,
            np.array(self.potential_solutions),
            None,
            self.gbest_scores,
        )

    def calculate_F_CR(self):
        def random_cauchy(u_F):
            return np.random.standard_cauchy(self.size) * 0.1 + u_F

        index_random = np.random.choice(self.H)
        selected_M_CR = self.M_CR[index_random]
        selected_M_F = self.M_F[index_random]

        self.mut = np.clip(random_cauchy(selected_M_CR), 0, 1)
        self.crossp = np.clip(
            np.random.normal(loc=selected_M_F, scale=0.1, size=self.size), 0, 1
        )

    def merge_A_P(self):
        if self.A is not None:
            return np.concatenate((self.X, self.A), axis=0)
        else:
            return self.X.copy()

    def operate_A(self, A_list):
        if len(A_list) != 0:
            if self.A is None:
                self.A = np.array(A_list)
            else:
                self.A = np.concatenate((self.A, np.array(A_list)), axis=0)
        # ???A?????????????????????????1?7
        if self.A.shape[0] > self.size:
            remain_index = np.random.choice(self.A.shape[0], self.size, replace=False)
            self.A = self.A[remain_index]

    def generate_mutant(self, mergeSet_A_P, individual_index):
        # ???p_best
        p = np.random.uniform(2 / self.size, 0.2)
        p_best_index = np.random.choice(np.argsort(self.X_score)[: int(self.size * p)])
        p_best = self.X[p_best_index]
        # ???x_r1??x_r2
        index_r1_list = [
            index for index in range(self.size) if index != individual_index
        ]
        r1_index = np.random.choice(index_r1_list)
        index_r2_list = [
            index
            for index in range(mergeSet_A_P.shape[0])
            if index != r1_index and index != individual_index
        ]
        r2_index = np.random.choice(index_r2_list)
        x_r1 = self.X[r1_index]
        x_r2 = mergeSet_A_P[r2_index]

        mutant = (
            self.X[individual_index]
            + self.mut[individual_index] * (p_best - self.X[individual_index])
            + self.mut[individual_index] * (x_r1 - x_r2)
        )
        mutant = np.clip(mutant, self.lb, self.ub)

        return mutant

    def plot_optimization(self):
        plt.semilogy(self.gbest_scores, "r-", linewidth=2)
        plt.xlabel("Iteration")
        plt.ylabel("Best Score")
        plt.title("SaDE Optimization Process")
        plt.show()
